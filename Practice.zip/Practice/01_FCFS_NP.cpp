#include <iostream>
using namespace std;

int main()
{
    int n;
    cout<<"Enter number of processes: ";
    cin>>n;

    int at[n], bt[n], ct[n], tat[n], wt[n];

    for(int i=0;i<n;i++)
    {
        cout<<"Arrival time of P"<<i+1<<": ";
        cin>>at[i];

        cout<<"Burst time of P"<<i+1<<": ";
        cin>>bt[i];
    }

    int time = 0;

    for(int i=0;i<n;i++)
    {
        if(time < at[i])
            time = at[i];

        ct[i] = time + bt[i];
        time = ct[i];
    }

    float avgWT = 0, avgTAT = 0;

    for(int i=0;i<n;i++)
    {
        tat[i] = ct[i] - at[i];
        wt[i] = tat[i] - bt[i];

        avgWT += wt[i];
        avgTAT += tat[i];
    }

    avgWT /= n;
    avgTAT /= n;

    cout<<"\nProcess\tAT\tBT\tCT\tTAT\tWT\n";

    for(int i=0;i<n;i++)
    {
        cout<<"P"<<i+1<<"\t"
            <<at[i]<<"\t"
            <<bt[i]<<"\t"
            <<ct[i]<<"\t"
            <<tat[i]<<"\t"
            <<wt[i]<<endl;
    }

    cout<<"\nAverage Waiting Time = "<<avgWT<<endl;
    cout<<"Average Turnaround Time = "<<avgTAT<<endl;

    return 0;
}